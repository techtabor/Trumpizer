# Trumpizer
Chrome Extension by Balázs Németh

Sets every image on a web page to Donald Trump's handsome picture.
It also sets the background of the web page to the slogan "Make America Great Again"

How to install:

1. Enter the chrome://extensions/ URL in your Chrome browser
2. Drag and drop the Trumpizer.crx file to this site
3. Done!
